package cw;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class bls  extends  JFrame implements ActionListener {
	JLabel z;
	JButton d;
	public static void main(String[] args) {
		new bls();

	}
public bls() {
	z=new JLabel("���Ȳ�ѯѧ���ǲ��ǽ��");
	d=new JButton("ȷ��");
	d.addActionListener(this);
	this.add(z);
	this.add(d);
	this.setLayout(new FlowLayout());
	this.setVisible(true);
	this.setSize(200, 100);
	this.setLocation(750, 330);
}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getActionCommand().equals("ȷ��")) {
			this.dispose();
		}
	}

}
