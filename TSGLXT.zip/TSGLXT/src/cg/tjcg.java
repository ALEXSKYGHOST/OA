package cg;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class tjcg extends  JFrame implements ActionListener {
	JLabel z;
	JButton d;
	public static void main(String[] args) {
		new tjcg();
		
	}
public tjcg() {
	z=new JLabel("���ѳɹ��������ӵ�ͼ���");
	d=new JButton("ȷ��");
	d.addActionListener(this);
	this.add(z);
	this.add(d);
	this.setLayout(new FlowLayout());
	this.setVisible(true);
	this.setSize(180, 150);
	this.setLocation(750, 330);
	
}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("ȷ��")) {
			this.dispose();
		}
		
	}

}
