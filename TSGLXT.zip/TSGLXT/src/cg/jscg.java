package cg;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class jscg extends  JFrame implements ActionListener {
	JLabel z;
	JButton d;
	public static void main(String[] args) {
		new jscg();


	}
	public jscg() {
		z=new JLabel("���ѳɹ�����");
		d=new JButton("ȷ��");
		d.addActionListener(this);
		this.add(z);
		this.add(d);
		this.setLayout(new FlowLayout());
		this.setVisible(true);
		this.setSize(100, 100);
		this.setLocation(750, 330);
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getActionCommand().equals("ȷ��")) {
			this.dispose();
		}
	}

}
