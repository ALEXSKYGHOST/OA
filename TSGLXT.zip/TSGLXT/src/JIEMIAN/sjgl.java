package JIEMIAN;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class sjgl extends  JFrame implements ActionListener {
	JLabel c1;
	JLabel c2;
	JLabel c3;
	JTextField q;
	JTextField q1;
	JTextField q2;
	JButton w;
	JButton w1;
	public static void main(String[] args) {
		new sjgl();
;
	}
	public sjgl() {
		c1=new JLabel("ͼ�����");
		c3=new JLabel("ͼ������");
		c2=new JLabel("ͼ������");
		
		q=new JTextField(10);
		q1=new JTextField(10);
		q2=new JTextField(10);
		w=new JButton("����");
		w.addActionListener(this);
		w1=new JButton("������һ����");
		w1.addActionListener(this);
		this.add(c1);
		this.add(q);
		this.add(c3);
		this.add(q2);
		this.add(c2);
		this.add(q1);
		this.add(w);
		this.add(w1);
		this.setTitle("ͼ������");
		this.setLocation(600, 500);
		this.setLayout(new FlowLayout());
		this.setVisible(true);
		this.setSize(200, 200);
		
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
