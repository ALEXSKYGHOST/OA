package JIEMIAN;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import qudong.lj;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class dljm extends  JFrame implements ActionListener{
	JLabel c1;
	JLabel c2;
	JTextField q;
	JTextField q1;
	JButton w;
	JButton w1;
	lj c=new lj();
	public static void main(String[] args) {
		new dljm();

	}
	public dljm() {
		c1=new JLabel("����Ա�˺�");
		c2=new JLabel("����Ա����");
		q=new JTextField(10);
		q1=new JTextField(10);
		w=new JButton("��½");
		w.addActionListener(this);
		w1=new JButton("������һ����");
		w1.addActionListener(this);
		this.add(c1);
		this.add(q);
		this.add(c2);
		this.add(q1);
		this.add(w);
		this.add(w1);
		this.setTitle("����Ա��½");
		this.setLocation(600, 300);
		this.setLayout(new FlowLayout());
		this.setVisible(true);
		this.setSize(600, 600);
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("������һ����")) {
			new xz();
			this.dispose();	
		}
		if(e.getActionCommand().equals("��½")) {
			
			
			c.qd();
			Statement stmt;
			try {
				String v=q.getText();
				int v1=Integer.parseInt(q1.getText());
				stmt = c.getCon().createStatement();
				ResultSet rs=stmt.executeQuery("SELECT * FROM gly");
				while(rs.next()) {
					if(rs.getString("zh").trim().equals(v)&&rs.getInt("mm")==v1) {
						new tjsjjm();
						this.dispose();
					}
					
				}
			} catch (SQLException e1) {
				System.out.println("11111");
				e1.printStackTrace();
			}
			c.gb();
		}
		
	}

}
