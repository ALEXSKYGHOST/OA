package JIEMIAN;
import qudong.lj;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import cg.tscg;
import cw.bls;

public class tsjm extends  JFrame implements ActionListener{
	lj c=new lj();
	JLabel h;
	JLabel h1;
	JLabel h2;
	JLabel h3;
	JLabel h4;
	JLabel h5;
	JTextField q;
	JButton f;
	JButton f1;
	JButton d1;
	public tsjm() {
		h=new JLabel();
		h1=new JLabel();
		h2=new JLabel();
		h3=new JLabel();
		h4=new JLabel();
		h5=new JLabel();
		q=new JTextField();
		d1=new JButton("������һ����");
		d1.addActionListener(this);
		f=new JButton("��ѯѧ����Ϣ");
		f.addActionListener(this);
		f1=new JButton("ȷ������");
		f1.addActionListener(this);
		this.add(q);
		this.add(f);
		this.add(h);
		this.add(h1);
		this.add(h2);
		this.add(h3);
		this.add(h4);
		this.add(h5);
		this.add(f1);
		this.add(d1);
		this.setLayout(new GridLayout(5,2));
		this.setSize(600, 600);
		this.setLocation(600, 300);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		new tsjm();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		c.qd();
		String num=q.getText();
		if(e.getActionCommand().equals("��ѯѧ����Ϣ")) {

			try {
				
				Statement stmt=c.getCon().createStatement();
				System.out.println("1");
				
				ResultSet rs=stmt.executeQuery("SELECT * FROM jsjm");
				System.out.println("2");
				while(rs.next()) {
					System.out.println("3");
					if(num.equals(rs.getString("xuhao").trim())) {
						h.setText("ѧ������");
						h1.setText(""+rs.getString("xm"));
						h2.setText("������");
						h3.setText(""+rs.getString("sh"));
						h4.setText("ѧ������Ѻ��");
						h5.setText(""+rs.getInt("yj"));
						c.gb();
						break;}
					else{
						h.setText("ѧ��û�����");
						h1.setText("ѧ��û�����");
						h2.setText("ѧ��û�����");
						h3.setText("ѧ��û�����");
						h4.setText("ѧ��û�����");
						h5.setText("ѧ��û�����");
					}

				}

			} catch (SQLException e1) {
				System.out.println("shibai");
				e1.printStackTrace();
			}
			
		}
		if(e.getActionCommand().equals("ȷ������")) {
			int i;
			String sh = null;
			Statement stmt ;
			
			try {
				stmt = c.getCon().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				ResultSet rs=stmt.executeQuery("SELECT * FROM jsjm  ");//����SQL����ѯ�����(����)
				while(rs.next()) {
					
					if(num.equals(rs.getString("xuhao").trim())) {
						sh=rs.getString("sh").trim();
						rs.moveToCurrentRow();
						rs.deleteRow();
						new tscg();
						break;
					}		
				}
						}catch (SQLException e1) {
							
								new bls();
							
				e1.printStackTrace();
			}//����SQL�������
			ResultSet rs1;
			try {
				c.getCon();
				Statement stmt1 = c.getCon().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				rs1 = stmt1.executeQuery("SELECT * FROM sjjm");
				while(rs1.next()) {
					if(rs1.getString("sh").trim().equals(sh)) {
						int b=rs1.getInt("sl")+1;
						i=rs1.getRow();
						rs1.absolute(i);
						rs1.moveToInsertRow();
						rs1.moveToCurrentRow();
						rs1.updateInt(3,  b);
						rs1.updateRow();
						break;
						
			} }}catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			c.gb();	}
			if(e.getActionCommand().equals("������һ����")) {
					new xz();
					this.dispose();
				}
			
			
		}}
