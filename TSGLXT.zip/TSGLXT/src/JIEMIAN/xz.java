package JIEMIAN;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class xz extends  JFrame implements ActionListener {
	JButton a;
	JButton a1;
	JButton a2;
	public static void main(String[] args) {
		new xz();

	}
	public xz() {
		a= new JButton("����Ա");
		a1= new JButton("����");
		a2= new JButton("����");
		this.add(a);
		this.add(a1);
		this.add(a2);
		a.addActionListener(this);
		a1.addActionListener(this);
		a2.addActionListener(this);
		this.setLayout(new GridLayout(3,1));
		this.setTitle("ͼ�����ϵͳ");
		this.setSize(600,600);
		this.setLocation(600,300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("����")) {
			new jsjm();
			this.dispose();
		}
		if(e.getActionCommand().equals("����")) {
			new tsjm();
			this.dispose();
		}
		if(e.getActionCommand().equals("����Ա")) {
			new dljm();
			this.dispose();
		}
	}

}
