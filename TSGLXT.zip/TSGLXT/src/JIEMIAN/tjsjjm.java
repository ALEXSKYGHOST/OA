package JIEMIAN;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import cg.tjcg;
import qudong.lj;

public class tjsjjm extends  JFrame implements ActionListener {
	int i;

	lj c=new lj();
	JLabel b;
	JLabel b1;
	JLabel b2;
	JTextField h;
	JTextField h1;
	JTextField h2;
	JButton e;
	JButton e1;
	public static void main(String[] args) {
		new tjsjjm();
		
	}
	public tjsjjm() {
		b=new JLabel("������Ҫ���ӵ����");
		b1=new JLabel("������Ҫ���ӵ�����");
		b2=new JLabel("������Ҫ���ӵ�����");
		h=new JTextField(40);
		h1=new JTextField(40);
		h2=new JTextField(40);
		e=new JButton("ȷ������");
		e.addActionListener(this);
		e1=new JButton("���ص�ѡ�����");
		e1.addActionListener(this);
		this.add(b);
		this.add(h);
		this.add(b1);
		this.add(h1);
		this.add(b2);
		this.add(h2);
		this.add(e);
		this.add(e1);
		this.setVisible(true);
		this.setSize(600, 600);
		this.setLayout(new FlowLayout());
		this.setLocation(600, 300);
		this.setTitle("ͼ���");
		
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		c.qd();
		if(arg0.getActionCommand().equals("ȷ������")) {
			String m=h.getText();
			String m1=h1.getText();
			int m2=Integer.parseInt(h2.getText());
			try {
				Statement stmt=c.getCon().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				ResultSet rs=stmt.executeQuery("SELECT * FROM sjjm");
				String sql="INSERT INTO sjjm VALUES(?,?,?)";
		        PreparedStatement pstmt=c.getCon().prepareStatement(sql);
		        pstmt.setString(1,m);
		        pstmt.setString(2,m1);
		        pstmt.setInt(3,m2);
		        pstmt.executeUpdate();
		        new tjcg();
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("��Ϊͼ������������ŵ�������ֻ��Ҫ������������");
				
				Statement stmt;
				
				try {
					stmt = c.getCon().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					ResultSet rs=stmt.executeQuery("SELECT * FROM sjjm");
					while(rs.next()) {
						System.out.println("1"+rs.getString("sh"));
					if(m.equals(rs.getString("sh").trim())) {
						System.out.println("1");
						int o=rs.getInt("sl")+m2;
						i=rs.getRow();
						rs.absolute(i);
						rs.moveToInsertRow();
						rs.moveToCurrentRow();
						rs.updateInt(3, o);
						rs.updateRow();
						new tjcg();
						System.out.println("�޸ĳɹ�");
				} }}catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}					
				}
			}
	
		if(arg0.getActionCommand().equals("���ص�ѡ�����")) {
			new xz();
			this.dispose();
		}
	}

	}
