package JIEMIAN;

import java.awt.BorderLayout;
import qudong.lj;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import cg.jscg;
import cw.jssb;

public class jsjm extends  JFrame implements ActionListener{
	DefaultTableModel model=new DefaultTableModel();

	JPanel a;
	JPanel b;
	JLabel z;
	JLabel z1;
	JLabel z2;
	JLabel z3;
	JLabel z4;
	JTextField q;
	JTextField q1;
	JTextField q2;
	JTextField q3;
	JButton d;
	JButton d1;
	lj c=new lj();
	public static void main(String[] args) {
		new jsjm();
		
	}

	public jsjm() {
		model.addColumn(new Object[]{"���","����","����"});
		model.setColumnIdentifiers(new Object[]{"���","����","����"});
		c.qd();
		c.getCon();
		Statement stmt;
		model.addRow(new Object[]{"���","����","����"});
		try {
			stmt = c.getCon().createStatement();
			ResultSet rs=stmt.executeQuery("SELECT * FROM sjjm");
			while(rs.next()) {
				String sh=rs.getString("sh");
				String sm=rs.getString("sm");
				int sl=rs.getInt("sl");
				model.addRow(new Object[]{sh,sm,sl});
			}


			c.gb();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String[] title = {"���","����","����"};
		JTable table=new JTable(model);
		table.enable(false);
		a=new JPanel();
		b=new JPanel();
		 JScrollPane c = new JScrollPane(b);
		d=new JButton("��");
		d1=new JButton("������һ����");
		z=new JLabel("����д������Ϣ");
		z1=new JLabel("ѧ��");
		z2=new JLabel("����");
		z3=new JLabel("���");
		z4=new JLabel("Ѻ��");
		q=new JTextField();
		q1=new JTextField();
		q2=new JTextField();
		q3=new JTextField();
		a.add(z1);
		a.add(q);
		a.add(z2);
		a.add(q1);
		a.add(z3);
		a.add(q3);
		a.add(z4);
		a.add(q2);
		a.add(d);
		a.add(d1);
		b.add(table);
		b.setVisible(true);
		a.setLayout(new GridLayout(5,2));
		d1.addActionListener(this);
		d.addActionListener(this);
		this.setSize(600, 600);
		this.setLocation(600, 300);
		this.setLayout(new BorderLayout());
		this.add(b,BorderLayout.EAST);
		this.add(a,BorderLayout.WEST);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getActionCommand().equals("������һ����")) {
			new xz();
			this.dispose();
		}
		if(arg0.getActionCommand().equals("��")) {
			String h=q.getText();
			String h1=q1.getText();
			String h3=q3.getText();
			int h2=Integer.parseInt(q2.getText());
			
			c.qd();
			 try {
				Statement stmt=c.getCon().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				String sql="INSERT INTO jsjm VALUES(?,?,?,?)";
		        PreparedStatement pstmt=c.getCon().prepareStatement(sql);
		        pstmt.setString(1,h);        
	        	  pstmt.setString(2, h1);    
	        	  pstmt.setString(3, h3);
	        	  pstmt.setInt(4, h2);
	        	  pstmt.executeUpdate();
	        	  ResultSet rs=stmt.executeQuery("SELECT * FROM sjjm");
	        	  int i;
	        	  while(rs.next()) {
	        		  if(rs.getString("sh").trim().equals(h3)&&rs.getInt("sl")!=0) {
	        			 int b=rs.getInt("sl")-1;
	        			 
	  		        	i=rs.getRow();
	  		        	rs.absolute(i);
	  		        	 rs.moveToInsertRow();
		  		        	rs.moveToCurrentRow();
		  		        	rs.updateInt(3,  b);
		  		        	 rs.updateRow();
	        			  break;
	        		  }
	        	  }
	        	  c.gb();
	        	  new jscg();
			 } catch (SQLException e) {
				 new jssb();
				e.printStackTrace();
				
			}
			
		}
	}

}
